export const Colors = {
  IconColor: '#797A7E',
  IconColorActive: '#016A70',
  TextColor: '#016A70',
  DarkGrayColor: '#555555',
  HeaderColor: '#EEEEEE',
  TextColor2: '#303841',
  TextColor3: '#797A7E',
  TextLinkColor: '#3A98B9',
  WarningColor: '#ED7D31',
}