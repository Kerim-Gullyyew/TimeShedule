import React from 'react';
import {View, Text} from 'react-native';
const MainStack: React.FC = () => {
  return (
    <View>
      <Text>MainStack</Text>
    </View>
  );
};
export default MainStack;
